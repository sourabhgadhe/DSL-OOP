/* Program for addition of two complex numbers */

#include <iostream>
using namespace std;

class complex_number
{
  public:
  int real, imag;
};

int main ()
{
  complex_number num1, num2, sum;

  cout << "Enter real and imaginary part of first complex number: " << endl;
  cin >> num1.real >> num1.imag;

  cout << "Enter real and imaginary part of second complex number: " << endl;
  cin >> num2.real >> num2.imag;

  sum.real = num1.real + num2.real;
  sum.imag = num1.imag + num2.imag;


cout << "Sum of two complex numbers = " << sum.real << " + " << sum.imag << "i"<<endl;
cout << "Difference of two complex numbers = " << sum.real << " - " << sum.imag << "i";




  return 0;
}

