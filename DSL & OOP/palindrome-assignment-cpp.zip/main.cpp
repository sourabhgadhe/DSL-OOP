#include<iostream>
#include<string.h>
using namespace std;

void pal(int n)
{
        int n1,sum,a;
        n1=n;
        sum=0;

        do
        {
                sum=sum*10;
                a=n%10;
                sum=sum+a;
                n=n/10;
        }while(n>0);
        if(sum==n1)
                cout<<n1<<" is a Palindrome";
        else
                cout<<n1<<" is not a Palindrome";

}

void pal(char a[])  
 {  
 int i,j,l=0;  
 l=strlen(a);  
 int f=0;  
 for(i=0,l=l-1;a[i]!='\0';i++,l--)  
 {  
 if(a[i]!=a[l])  
 {  
 f=1;  
 break;  
 }  
 }  
 if(f==1)  
 {  
cout<<a<<" is not a Palindrome";   
 }  
 else if(f==0)  
cout<<a<<" is a Palindrome";  
 }  
 
int main()
{
        char c[10];
        int k,r,v;
        
        do
        {
                cout<<"\n>> Check Palindrome <<"<<endl;
                cout<<"\n1.for interger"<<endl;
                cout<<"2.for character"<<endl;
                cout<<"\nEnter the choice: ";
                cin>>r;
                switch(r)
                {
                        case 1:
                                cout<<"\nEnter the number: ";
                                cin>>k;
                                pal(k);
                                break;

                        case 2:
                                cout<<"\nEnter the string to be checked (without any space) : ";
                                cin>>c;
                                pal(c);
                                break;
                }
                cout<<"\n\nDo you want to continue? (1/0): ";
                cin>>v;
        }while(v==1);
        return 0;
}

