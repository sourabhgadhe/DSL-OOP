# Linear Search
def linear_search( roll_list , q ):
    for x in roll_list:
        if x==q:
            return 1

    return -1
        
# Sentinel search

def SentinelSearch(arr, n, key):
 
    # Last element of the array
    last = arr[n - 1]
 
    # Element to be searched is
    # placed at the last index
    arr[n - 1] = key
    i = 0
 
    while (arr[i] != key):
        i += 1
 
    # Put the last element back
    arr[n - 1] = last
 
    if ((i < n - 1) or (arr[n - 1] == key)):
        return 2
    else:
        pass


        
std = int(input("Enter the no. of students who attended the training program: "))

roll_list=[]

for i in range (0,std):
    roll=int(input("Enter their roll no.s: "))
    roll_list.append(roll)
print("\nRoll List of attendees: ",roll_list)

q=int(input("\nEnter the roll no. you want to search: "))
    
print("\n*** MENU ***")
print("\nSearch using: ")
print("\n1.Linear Search")
print("2.Sentinel Search")
print("3.Exit()")

c=int(input("\nEnter a choice: "))
if c==1:
    if linear_search( roll_list , q )==1:
        print("\nStudent attended the training program !!")
    elif linear_search( roll_list , q )== -1:
        print("\nStudent did not attended the training program !!")
        
elif c==2:
    if SentinelSearch(roll_list,len(roll_list),q)==2:
        print("\nStudent attended the training program !!")
    else:
        print("\nStudent did not attended the training program !!")
        
elif c==3:
    exit()








        
            


    














