# include <iostream>
using namespace std;


/*class Website
{
    public:
    int i;
    Website()
    {
        cout<<"Hello"<<endl;
    }
};


int main()
{
    Website w1,w2,w3;
    
    return 0;
} */



/*class Add
{
    public:
    
    Add(int a, int b)
    {
                cout<<"Addition is: "<<a+b;
    }
};

int main()
{
    Add a1(5,13);
    return 0;
    
}*/



/*class HelloWorld
{
    public:
    HelloWorld()
    {
        cout<<"Constructor is called !!"<<endl;
    }
    
    ~ HelloWorld()  // Destructor is called when scope of the main function ends
    {
        cout<<"Destructor is called !!"<<endl;
    }
    
    void display()
    {
        cout<<"Display function is called !!"<<endl;
    }
};

int main()
{   HelloWorld h1;
    h1.display();
    return 0;
}*/


/*int main()
{   
    enum month {jan, feb=5, mar, apr, may=4, june, july, aug=7, sept, oct=12, nov, dec};
    cout<<jan<<endl;
    cout<<mar;
    return 0;
}*/



/*class Person
{   
    public:
    string name;
    int age;
    void getdata();
    void displaydata();
};

void Person :: getdata()
{   
    cout<<"Enter your name: "<<endl;
    cin>>name;
    cout<<"Enter your age: "<<endl;
    cin>>age;
}

void Person :: displaydata()
{
    cout<<"Your name is: "<<name<<endl;
    cout<<"Your age is: "<<age;
}

int main()
{
    Person p1;
    p1.getdata();
    p1.displaydata();
    
    return 0;
}*/



// int main()
// {   
//     int *age = new int;
//     char *gender = new char;
//     *age=0;
//     *gender='M';
//     cout<<"Enter your age: ";
//     cin>> *age;
//     cout<<"Enter your gender M or F: ";
//     cin>> gender;
//     cout<<"\nAGE is: "<< *age << "\nGENDER is: "<< *gender <<endl;
    
//     return 0;
// }

class Rectangle
{
    int length, width;
    public:
    
    Rectangle(){
        length=2;
        width=5;
        
    }
    Rectangle(int l, int w){
        length = l;
        width = w;
    }
    void area(){
        cout<<"Area of Rectangle is "<< length*width<<endl;
        
    }
};

int main()
{
    Rectangle *obj_1 , *obj_2;
    obj_1 = new Rectangle();        // Dynamic memory allocation
    obj_2 = new Rectangle(3 ,10);   // Dynamic memory allocation
    obj_1->area();
    obj_2->area();
    return 0;
    
}

















