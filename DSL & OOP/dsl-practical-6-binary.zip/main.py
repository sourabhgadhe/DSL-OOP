# Write a python program to store roll numbers of student array who attended training
# program in sorted order. Write function for searching whether particular student
# attended training program or not, using Binary search and Fibonacci search

std = int(input("Enter the no. of students who attended the training program: "))

roll_list=[]

for i in range (0,std):
    roll=int(input("Enter their roll no.s: "))
    roll_list.append(roll)
print("\nRoll List of attendees: ",roll_list)

def perct(arr,low,high):
    pivot=arr[high]
    item=low-1
    for i in range(low,high):
        if(arr[i]<=pivot):
            item=item+1
            arr[item],arr[i]=arr[i],arr[item]
    arr[item+1],arr[high]=arr[high],arr[item+1]
    
    return item+1
    
def quicksort(arr,low,high):
    if low<high:
     pivot=perct(arr,low,high)
     quicksort(arr,low,pivot-1)
     quicksort(arr,pivot+1,high)


quicksort(roll_list,0,len(roll_list)-1)
print("The sorted list is: ",roll_list)

# Binary Search

list=roll_list
x=int(input("\nEnter the roll no. you want to search: "))

def binary_search(list, l, r, x):
    while l <= r:

        mid = (l + r) // 2;

        if list[mid] == x:
            return 1

        elif list[mid] < x:
            l = mid + 1

        else:
            r = mid - 1

    # If we reach here, then the element
    # was not present
    return -1   
        
        
def FibSearch(list, x,std):    
    # Initialize Fibonacci numbers           #fib nos 0,1,1,2,3,5,8,13,21,34,55,89......
    b = 0 
    a = 1 
    f = b + a 

    while (f < std): 
        b = a 
        a = f 
        f = b + a 
 
    offset = -1; 

 
    while (f > 1): 

        i = min(offset+b, std-1) 
  
        if (list[i] < x): 
            f = a 
            a = b
            b = f - a
            offset = i 


        elif (list[i] > x): 
            f = b 
            a = a - b 
            b = f - a


        else : 
            return i 

    if(a and list[offset+1] == x): 
        return offset+1; 

    return -1

    
print("\n*** MENU ***")
print("\nSearch using: ")
print("\n1.Binary Search")
print("2.Fibonacci Search")
print("3.Exit()")

c=int(input("\nEnter a choice: "))
if c==1:
    result = binary_search(list,0,len(roll_list)-1,x)
    if result == 1:
        print("\nStudent attended the training program !!")
    elif result == -1:
        print("\nStudent did not attended the training program !!")
    
elif c == 2:
    index = FibSearch(list,x,std)
    if index == -1:
        print("\nStudent did not attended the training program !!")
    else:
        print("\nStudent attended the training program !!")
        
elif c==3:
    print("\n>> THANK YOU FOR USING THE PROGRAM <<")
    exit() 
































