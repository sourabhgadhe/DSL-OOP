
#include <bits/stdc++.h>
using namespace std;

class Factorial
{
    private:
    int n,n1,f=1;
    public:
    void input();
    void calc();
    
};

void Factorial::input()
{
    cout<<"Enter any positive number: ";
    cin>>n;
}

void Factorial::calc()
{
    n1=n;
    if(n==0 or n==1)
    cout<<"Factorial of "<<n<<" is "<<"1"<<endl;
    
    else if(n<1)
    {
        cout<<"Factorial of nagative no.s cannot be determined !!"<<endl;
        
    }
    
    else if (n>1) 
    {
      while(n>0)
        {
            f=f*n;
            n--;
        }
        
        cout<<"Factorial of "<<n1<<" is "<<f<<endl;
    }


    else
    {
        cout<<"Error"<<endl;
    }
    
}


int main()
{
    Factorial a;
    a.input();
    a.calc();
    

    return 0;
}
