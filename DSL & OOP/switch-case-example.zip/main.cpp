
#include <iostream>
using namespace std;

int main ()
{
  float m, n;
  int c;

  cout << "Enter two numbers : ";
  cin >> m;
  cin >> n;
  
  
  cout << "Press 1 for addition"<<endl; 
  cout << "Press 2 for subtraction"<<endl;
  cout << "Press 3 for multiplication"<<endl;
  cout << "Press 4 for division"<<endl;
  
  
cin >> c;
switch (c)
    {
    case 1:
      cout << m + n;
      break;

    case 2:
      cout << m - n;
      break;

    case 3:
      cout << m * n;
      break;

    case 4:
      cout << m / n;
      break;

    default:
      cout << "Please enter numbers between 1 to 4";
      break;


    }
}
