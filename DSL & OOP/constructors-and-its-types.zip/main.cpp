
#include <bits/stdc++.h>
using namespace std;

// Default Constructor
/*
class Cube
{
    public:
    int side;
    Cube()     // Constructor
    {
       side=10; 
    }    
    
    
};

int main()
{
   Cube c;
   cout<<c.side;

    return 0;
} */
  


/*
//parameterised Constructor  
class Cube
{
    public:
    int side;
    Cube(int x)
    
    {
        side=x;
    }
    
};

int main()
{
  Cube c1(10);
  Cube c2(20);
  Cube c3(30);
  cout<<c1.side<<endl;
  cout<<c2.side<<endl;
  cout<<c3.side;
  
    return 0;
} */



//Copy Constructor

class Integer
{
    int m,n;
    public:
    Integer()
    {
        m=0;n=0;
    }
    Integer(int a,int b)
    {
        m=a;n=b;
    }
    Integer(Integer &i)    // copy Constructor defined
    {
        m=i.m;
        n=i.n;
        cout<<m <<n;
        
    }
};

int main()
{
    Integer i1;
    Integer i2(20,40);
    Integer i3(i1);          // m=0 , n=0
    Integer i4(i2);         // m=20 , n=40
    
    
    return 0;
} 

//program including Constructor


/*
class Box
{   public:
    double length;
    double breadth;
    double height;
    
    double getVolume(void);
    void setLength(double len);
    void setBreadth(double bre);
    void setHeight(double hei);
};

double Box::getVolume(void)
{
    return length*breadth*height;
}

void Box::setLength(double len)
{
    length=len;
}

void Box::setBreadth(double bre)
{
    breadth=bre;
}

void Box::setHeight(double hei)
{
    height=hei;
}


int main()
{
    Box Box1;
    Box Box2;
    double volume=0.0;
    
    Box1.setLength(6.0);
    Box1.setBreadth(7.0);
    Box1.setHeight(5.0);
    
    Box2.setLength(12.0);
    Box2.setBreadth(13.0);
    Box2.setHeight(10.0);
    
    volume=
    Box1.getVolume();
    cout<<"Volume of Box1: "<<volume<<endl;
    
    volume=
    Box2.getVolume();
    cout<<"Volume of Box2: "<<volume<<endl;
    
    return 0;
} */


  
  




