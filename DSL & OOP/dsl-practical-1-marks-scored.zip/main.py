'''Write a python program to store marks scored in subject FDS by N students in the class. Wrie functions to compute following:
a) The average score of class
b) Highest and lowest score of class
c) Count of students who were absent for the test
d) Display mark with highest frequency '''
    
total_students=int(input("Total no. of students are: "))
absent_list = []
scores_list = []
avg_score = 0
sum_score = 0
most_score = 0
print("Note: Enter marks of absent students as -1")

for i in range (0,total_students):
    score= int(input("Enter the marks of students: "))
    pass 
    if(score==-1):
        student_name = input("Enter the absent student name: ")
        absent_list.append(student_name)
        continue
    else:
        scores_list.append(score)
    
for j in scores_list :
    sum_score+=j

avg_score= sum_score/len(scores_list)
max_score= max(scores_list)
min_score= min(scores_list)

count=0
most_score= scores_list[0]
for k in scores_list:
    currentmost= scores_list.count(k)
    if(currentmost>count):
        count=currentmost
        most_score = k
print("\nThe avg score of class is ", avg_score)
print("The highest score in class is ", max_score)
print("The lowest score in class is ", min_score)
print("Score with highest frequency is: ", most_score)
print("The list of absent students is ", absent_list)


















        



