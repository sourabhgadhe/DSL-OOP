// Implement a class Complex which represents the Complex Number data type. Implement
// the following
// 1. Constructor (including a default constructor which creates the complex number 0+0i).
// 2. Overloaded operator+ to add two complex numbers.
// 3. Overloaded operator* to multiply two complex numbers.
// 4. Overloaded << and >> to print and read Complex Numbers.

#include <iostream>
using namespace std;

class Complex {

 float real, imag;
public:

 //constructor
 Complex() 
 {
     real = 0;
     imag = 0;
 }
 
 //friend functions of complex class
 friend ostream & operator << (ostream &out, Complex &obj);
 friend istream & operator >> (istream &in, Complex &obj);
 
 //overloading of + operator
 Complex operator + (Complex  &obj)
 {
 Complex res;
 res.real = real + obj.real;
 res.imag = imag + obj.imag;
 return res;
 }
 
 //overloading of * operator
 Complex operator * (Complex const &obj)
 {
 Complex res;
 res.real=((real)*(obj.real))-((imag)*(obj.imag));
 res.imag=((imag)*(obj.real))+((real)*(obj.imag));
 return res;
 }
};

 //overloading of << operator
ostream & operator << (ostream &out, Complex &obj)
{
 out << obj.real<<" + "<<obj.imag<<"i"<<endl;
 return out;
}

 //overloading of >> operator
istream & operator >> (istream &in, Complex &obj)
{
 cout << "\n Enter Real Part: "<<endl;
 in >> obj.real;
 cout << "\n Enter Imag Part: "<<endl;
 in >> obj.imag;
 return in;
}

int main()
{
 Complex c1,c2,c3,c4;
 cout <<"\n ** First Number ** ";
 cin >> c1;
 cout <<"\n  ** Second Number ** ";
 cin >> c2;
 
 //Addition
 c3 = c1 + c2;
 cout << "\n The Addition is : " <<c3 ;

 //Multiplication
 c4 = c1 * c2;
 cout << "\n\n The Multiplication is : " <<c4 <<endl;
 return 0;
}

