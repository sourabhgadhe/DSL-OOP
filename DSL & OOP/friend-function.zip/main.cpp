# include <iostream>
using namespace std;

class Item
{
    
    int num1;
    float num2;
    
    public:
    void putdata()
    {
        int a,b;
        cout<<"Enter first number : ";
        cin>>a;
        cout<<"Enter second number : ";
        cin>>b;
        num1=a;
        num2=b;
        
    }
    
    void getdata()
    {
        cout<<"First no. is: "<<num1<<endl;
        cout<<"Second no. is: "<<num2<<endl;
        
    }
    
    friend void display(Item s);
};

void display(Item s)
{
    cout<<"Addition is: "<<s.num1+s.num2;
}

int main()
{
    Item i1;
    i1.putdata();
    i1.getdata();
    display(i1);   
    return 0;
}

















