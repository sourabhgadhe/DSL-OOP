# include <iostream>
using namespace std;

class Students
{
    public:
    string name;
    int rollNo;
    
    
    void Name()
{
    cout<<"Enter ur name: "<<endl;
    cin>>name;
}

    void RollNo()
{
    cout<<"Enter ur rollNo: "<<endl;
    cin>>rollNo;
}

    void display()
    {
        cout<<"Your name is: "<<name<<endl;
        cout<<"Your roll no. is: "<<rollNo;
    }
    
};



int main()
{
    Students s1;
    s1.Name();
    s1.RollNo();
    s1.display();
    
    
    return 0;
}