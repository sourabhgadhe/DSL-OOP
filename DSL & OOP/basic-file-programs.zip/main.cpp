# include <iostream>
# include <fstream>
using namespace std;

// int main()
// {
//     fstream file;
//     file.open("sample.txt",ios::out);
//     file<<"My name is sourabh !!";
    
//     if(!file)
//     {
//         cout<<"\nFile not created !!"<<endl;
//     }
//     else
//     {
//         cout<<"\nFile created successfully !!"<<endl;
//     }
    
//     file.close();
    
//     return 0;
// }





// int main()
// {
//     fstream file;
//     file.open("sample.txt",ios::out);
//     file<<"My name is sourabh !!";
//     cout<<"Data Written to the file !!"<<endl;
    
//     file.close();
    
//     fstream my_file;
// 	my_file.open("sample.txt", ios::in);
// 	if (!my_file) {
// 		cout << "No such file";
// 	}
// 	else {
// 		string ch;

// 		while (1) {
// 			my_file >> ch;
// 			if (my_file.eof())
// 				break;
            
// 			cout << ch;
			
// 		}
//         cout<<"\nData accessed from file !!"<<endl;
// 	}
// 	my_file.close();
	
//     return 0;
// }






// class student {
//     int id;
//     char Name[20];
 
// public:
//     void display(int K);
// };
 
// void student::display(int K)
// {
//     fstream fs;
//     fs.open("student.dat", ios::in);
//     // using seekg(pos) method
//     // to place pointer at 7th record
//     fs.seekg(K * sizeof(student));
 
//     // reading Kth record
//     fs.read((char*)this, sizeof(student));
 
//     // using tellg() to display current position
//     cout << "Current Position: "
//          << "student no: "
//          << fs.tellg() / sizeof(student) - 200;
 
//     // using seekg()place pointer at end of file
//     fs.seekg(0, ios::end);
 
//     cout << " of "
//          << fs.tellg() / sizeof(student)
//          << endl;
//     fs.close();
// }
 
// // Driver code
// int main()
// {
 
//     // Record number of the student to be read
//     int K = 7;
 
//     student s;
//     s.display(K);
 
//     return 0;
// }

int main()
{
    char name[20];
    int roll;
    
    fstream file;
    file.open("sample.txt",ios::out);
    cout<<"Enter your name: ";
    cin.getline(name,20);
    cout<<"Enter your roll no.: " ;
    cin>>roll;
    
    file<<"Entered name is: "<<name;
    file<<"\nEntered roll no. is: "<<roll;
    file.close();
    
    string content;
    fstream f;
    f.open("sample.txt",ios::in);
    while(!f.eof())
    {
        getline(f,content);
        cout<<content;
    }
    
    f.close();
    
    return 0;
}













