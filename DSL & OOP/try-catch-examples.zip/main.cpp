#include <bits/stdc++.h>
using namespace std;

// int main()
// {
//     float num1, num2;

//     try{
//         cout<<"Enter first number: ";
//         cin>>num1;
//         cout<<"Enter second number: ";
//         cin>>num2;

//         if (num2 == 0)
//         {
//             throw num2;
//         }


//         else{
//             cout<<"Division is: "<<num1/num2;
//         }

//     }

//     catch(float num2)
//         {
//             cout<<"Can't divide by zero !!";
//         }


//     return 0;
// }







// int main()
// {
//     int age;

//     try
//     {
//         cout<<"Enter your age: ";
//         cin>>age;

//         if(age<18 && age>0)
//         {
//             throw age;
//         }

//         else if (age<=0)
//         {
//             throw "invalid";
//         }

//         else
//         {
//             cout<<"You are eligible to vote";
//         }
//     }

//     catch (int age)
//     {
//         cout<<"You are not eligible to vote";
//     }

//     catch(...)
//     {
//         cout<<"Invaid input !!";
//     }

// }






// int main()
// {
//     int marks;

//     try
//     {
//         cout<<"Enter your marks: ";
//         cin >> marks;

//         if (marks<0 || marks >100)
//         {
//             throw marks;
//         }

//         else
//         {
//             cout<<"Entered marks are: "<<marks;
//         }
//     }

//     catch(int marks)
//     {
//         cout<<"Pls enter correct marks !!";
//     }

//     return 0;
// }









// void display(int id,float amt,int age)
// {
//      try
//      {
//          if (id<0)
//          {
//              throw false; 
//          }
//              if(amt<1000)
//              {
//                      throw 1;
//              }
//              if(age<18)
//              {
//                      throw 'A';
//              }
//              cout<<"\nAccount opened successfully !!";
//      }
//      catch(int n)
//      {
//              cout<<"\nAccount can't be opened with amountless than Rs. 1000";

//      }
//      catch(char ch)
//      {
//              cout<<"\nInvalid age for account opening !!";

//      }
// }
// int main() 
// {
//     cout<<"\nWelcome to Union Bank of India !!\n";
//      int id,age;
//      float amt;
//      cout<<"\nEnter customer id :";
//      cin>>id;
//      cout<<"\nEnter amount :";
//      cin>>amt;
//      cout<<"\nEnter age :";
//      cin>>age;

//      try
//      {

//              display(id,amt,age);
//              cout<<"\nThank You...For Banking with us";
//      }
//      catch(...)  //generic exception
//      {
//              cout<<"\nSome error occured";
//      }

//      return 0;
// }






#include<iostream>
#include<string.h>
#include<cctype>
using namespace std;

int main()
{
     string test;
     string email;
     bool isChar();
     bool isDigit();
     bool isValidEmailId(string);

     cout<<"\n Enter Email Id : ";
     getline(cin, email);

     test=email;
     try //Exceptions are thrown from inside the try block.
     {
          if(isValidEmailId(test) )
               cout<<"\n Email Id is Valid.";
          else
               throw 'c';  //Exception is thrown. The control is transferred to catch block
               //cout<<"\n Email Id is Invalid";
     }
     catch(char c)   //Catch block catches the exception thrown by throw statement from try block.
                    //Then, the exceptions are handled inside catch block.
     {
          cout<<"\n Exception Caught... \n Invalid Email Id!!!";
     }
     catch(...)  //This exception can catch all those exceptions which are not handled by other catch statements.
     {
          cout<<"\n Default Exception";
     }
     return 0;
}
bool isChar(const char Character)
{
     return ( (Character >= 'a' && Character <= 'z') || (Character >= 'A' && Character <= 'Z'));
}
bool isDigit(const char Character)
{
     return ( Character >= '0' && Character <= '9');
}
bool isValidEmailId(string email)
{
     //if(!email)
     //return 0;
     if(!isChar(email[0]))
          return 0;
     int AtOffset = -1;
     int DotOffset = -1;
     unsigned int Length;
     for(unsigned int i = 0; i < Length; i++)
     {
          if(email[i] == '@')
               AtOffset = (int)i;
          else if(email[i] == '.')
               DotOffset = (int)i;
     }
     if(AtOffset == -1 || DotOffset == -1)
          return 0;
     if(AtOffset > DotOffset)
          return 0;
     return !(DotOffset >= ((int)Length-1));
}












