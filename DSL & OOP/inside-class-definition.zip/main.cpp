
#include <bits/stdc++.h>
using namespace std;

/* class Fruits
{
   public:
   string name;
   int qty;
   
   void insert(string n, int i)
   {
       name=n;
       qty=i;
   }
   void display()
   {
       cout<<name<<" "<< qty<<endl;
   }
};

int main()
{
Fruits f1;
Fruits f2;
f1.insert("Banana",1);
f2.insert("Chickoo",2);
f1.display();
f2.display();

    return 0;
} */



/* class Room
{
    public:
    double length;
    double breadth;
    double height;
    
    double calculateArea()
    {
        return length*breadth;
    }
    
    double calculateVolume()
    {
        return length*breadth*height;
    }
};

int main()
{
    Room r1;
    
    r1.length=2;
    r1.breadth=2;
    r1.height=2;
    
    cout<<"Area of Room = "<<r1.calculateArea()<<endl;
    cout<<"Volume of room = "<<r1.calculateVolume();
    
    
    return 0;
}  */














