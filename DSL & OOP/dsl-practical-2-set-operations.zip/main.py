'''In second year computer engineering class, group A students play cricket,
group B students play badminton.
Write a python program using functions to compute following: -
a) List of students who play either cricket or badminton or both
b) List of students who play both cricket and badminton
c) List of students who play only cricket
d) List of students who play only badminton
e) List of students who play neither cricket nor badminton.
'''


lst1=[]
l=int(input("Enter total no. of students: "))
print("Enter their roll no.s: ")

for i in range (0,l):
    total=int(input())
    lst1.append(total)

lst2=[]
m=int(input("Enter no. of students who play cricket: "))
print("Enter their roll no.s: ")
for j in range (0,m):
    cricket=int(input())
    lst2.append(cricket)
    
lst3=[]
n=int(input("Enter no. of students who play badminton: "))
print("Enter their roll no.s: ")
for k in range (0,n):
    badminton=int(input())
    lst3.append(badminton)


        
set1=set(lst1)
set2=set(lst2)
set3=set(lst3)


print("\nSet of total roll no. of students is : ",set1)
print("Set of roll no.s of students who play cricket: ", set2)
print("Set of roll no.s of students who play badminton: ", set3)



print("Set of roll no.s of students who play either cricket or badminton or both: ",set2|set3)
print("Set of roll no.s of students who play both cricket and badminton: ",set2&set3)
print("Set of roll no.s of students who play only cricket: ",set2-set3)
print("Set of roll no.s of students who play only badminton: ",set3-set2)

lst4=[]
for z in lst1:
    if z not in set2|set3:
        lst4.append(z)

set4=set(lst4)

print("Set of roll no.s of students who play neither cricket nor badminton: ",set4)




    

