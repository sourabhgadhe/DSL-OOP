
#include <iostream>
using namespace std;

void sum(int x[],int y[])
{
    int result[5];
    
    for(int i=0;i<5;i++)
    {
        result[i]=x[i]+y[i];
        cout<<result[i]<<endl;
    }
}

int main()
{
    int arr1[5]={10,20,30,40,50};
    int arr2[5]={1,2,3,4,5};
    sum(arr1,arr2);
    
    return 0;
}


