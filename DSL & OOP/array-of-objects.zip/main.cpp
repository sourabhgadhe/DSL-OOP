
#include <bits/stdc++.h>
using namespace std;
class Item
{
    int itemno;
    float price;
    public:
    void getdata(int i,float f)
    {
        itemno=i;
        price=f;
    }
    
    void putdata(void)
    {
        cout<<"Itemno: "<<itemno<<endl;
        cout<<"Price: "<<price<<endl;
    }
};

Item order[5];

int main()
{
    int ino;
    float cost;
    for (int z=0; z<5; z++)
    {
        cout<<"Enter itemno and item price for item: "<<z+1<<endl;
        cin>>ino>>cost;
        order[z].getdata(ino,cost);
    }
    cout<<"\n";
    for(int z=0; z<5; z++)
    {
        cout<<"Item"<<z+1<<endl;
        order[z].putdata();
    }

    return 0;
}
