'''Write a python program to store first year percentage of students in array. Write function
for sorting array of floating point numbers in ascending order using
a) Selection Sort
b) Bubble sort and display top five scores.
'''

marks=[]
n = int(input("Enter number of students whose marks are to be displayed : "))
print("Enter marks for",n,"students (Press ENTER after every students marks): ")
for i in range(0, n):
    ele = int(input())
    marks.append(ele)  # adding the element

print("\nThe marks of",n,"students are : ")
print(marks)

def Bubble_Sort(marks):
    p = len(marks)
    for i in range(p - 1):
        for j in range(0, p - i - 1):

            if marks[j] > marks[j + 1]:
                marks[j], marks[j + 1] = marks[j + 1], marks[j]
    

    print("\nMarks of students after performing Bubble Sort on the list :")
    for i in range(len(marks)):
        print(marks[i])
        
topmarks=[]        
        
def Selection_Sort(marks):
    for i in range(len(marks)):

        # Find the minimum element in remaining unsorted array
        min_idx = i
        for j in range(i + 1, len(marks)):
            if marks[min_idx] > marks[j]:
                min_idx = j

        # Swap the minimum element with the first element
        marks[i], marks[min_idx] = marks[min_idx], marks[i]

    print("\nMarks of students after performing Selection Sort on the list : ")
    for i in range(len(marks)):
        print(marks[i])
        topmarks.append(marks[i])
        

        
def top_five_marks(marks):
    tfm = []
    print("\nThe top 5 marks are: ")
    i=len(topmarks)-1
    while i>=0:
        tfm.append(topmarks[i])
        i=i-1
    
    print(tfm[0:5])
        
    
Bubble_Sort(marks)
Selection_Sort(marks)
top_five_marks(marks) 









        
        

        





