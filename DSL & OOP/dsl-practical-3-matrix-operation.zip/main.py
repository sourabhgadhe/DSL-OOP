'''Write a python program to compute following computation on matrix:
a) Addition of two matrices
b) Subtraction of two matrices
c) Multiplication of two matrices
d) Transpose of a matrix
'''

rows = int(input("Enter the Number of Rows: " ))
column = int(input("Enter the Number of Columns: "))

if rows!=column:
    print("Please Enter a Square Matrix of equal rows and columns !!")
    exit()      #(exits the program)
    

print("Enter the elements of First Matrix:")

matrix_a= [[int(input()) for i in range(column)] for i in range(rows)]
for n in matrix_a:
    print(n)

print("Enter the elements of Second Matrix:")

matrix_b= [[int(input()) for i in range(column)] for i in range(rows)]
for n in matrix_b:
    print(n)
    
result=[[0 for i in range(column)] for i in range(rows)]

#Addition of two Matrices
for i in range(rows):
    for j in range(column):
        result[i][j] = matrix_a[i][j] + matrix_b[i][j]

print("\nThe Addition of Above two Matrices is : ")
for r in result:
    print(r)
    
#Subtraction of two Matrices
for i in range(rows):
    for j in range(column):
        result[i][j] = matrix_a[i][j] - matrix_b[i][j]

print("The Subtraction of Above two Matrices is : ")
for r in result:
    print(r)
    
# Multilication of two Matrices

mul=[[0 for i in range(column)] for i in range(rows)]

for i in range(rows):
    for j in range(column):
        for k in range (len(matrix_b)):
            mul[i][j] += matrix_a[i][k] * matrix_b[k][j]

print("The Multiplication of the two entered Matrices is : ")                 
for r in mul:
    print(r)
     
# Transpose of a matrix_a
t=matrix_a
for i in range(rows):
    for j in range(column):
        if (i!=j and i<j):
            s=t[i][j]
            t[i][j]=t[j][i]
            t[j][i]=s
        else:
            pass
print("The Transpose of matrix_a is: ")
for r in t:
    print(r)
    
    
# Transpose of a matrix_b   
p=matrix_b
for i in range(rows):
    for j in range(column):
        if (i!=j and i<j):
            z=p[i][j]
            p[i][j]=p[j][i]
            p[j][i]=z
        else:
            pass
print("The Transpose of matrix_b is: ")
for r in p:
    print(r)
            
            

       
        

       



















    





