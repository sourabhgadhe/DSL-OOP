
#include <iostream>
using namespace std;
template <class S>      // Note that S is not a class name

S compare(S a, S b)     // template function
{
    if(a>b)
    return a;   // if
    return b;   // else
}

int main()
{
    cout<<compare(2,3)<<endl;
    cout<<compare('a','d')<<endl;
    cout<<compare(123.4 , 32.0)<<endl;
    
    return 0;
}

