# include <iostream>
using namespace std;

class Rectangle
{
    float l;
    float b;
    
    public:
    
    Rectangle()
    {
        l=34.3;
        b=22.4;
    }
    friend class Square;
};

class Square
{
    float s;
    
    public:
    Square()
    {
        s=22.3;
    }
    
    void display(Rectangle r)
    {
        cout<<"The Length of the Rectangle is: "<<r.l<<endl;
        cout<<"The Breadth of the Rectangle is: "<<r.b<<endl;
        cout<<"The side of the Square is: "<<s;
    }
    
};

int main()
{   Rectangle r1;
    Square s1;
    s1.display(r1);
    return 0;
}

