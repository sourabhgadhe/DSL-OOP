#include <iostream>
using namespace std;

// void f(int val) throw(int, char)
// {
//   if(val==0) 
//      throw val;
//   if(val==1) 
//      throw 'a';
//   if(val==2) 
//      throw 123.23;
// }

// int main()
// {
//   try{
//     f(1);     // if 2 is passed it will throw an error
//   }
//   catch(int i) {
//     cout << "Caught an integer\n";
//   }
//   catch(char c) { 
//     cout << "Caught char\n";
//   }
//   catch(double d) { 
//     cout << "Caught double\n";
//   }
//   return 0;
// }




// class A
// {
//     public:
    
//     A()        // constructor
//     {
//         try
//         {
//             throw 'e';
//         }
        
//         catch(char e)
//         {
//             cout<<"Exception handled in constructor"<<endl;
//         }
//     }
    
//     ~A()    // destructor
//     {
//         try
//         {
//             throw 1;
//         }
        
//         catch(int a)
//         {
//             cout<<"Exception handled in destructor"<<endl;
//         }
//     }
    
// };

// int main()
// {
//     A a;
//     return 0;
// }




// #include <iostream>
// using namespace std;

// int main() 
// {
// 	int i,j,n;
// 	int min,temp,arr[10];
	
// 	cout<<">> Selection Sort <<\n";
// 	cout<<"\nHow many numbers are there in array to be sorted: ";
// 	cin>>n;
	
// 	cout<<"\nEnter those numbers: \n";
// 	for(int i=0;i<n;i++)
// 	{
// 		cin>>arr[i];
// 	}
	
// 	for(i=0;i<n-1;i++)
// 	{
// 		min=i;
// 		for(j=i+1;j<n;j++)
// 		{
// 			if(arr[j]<arr[min])
// 			{
// 				min=j;
// 			}
// 		}
// 		temp=arr[i];
// 		arr[i]=arr[min];
// 		arr[min]=temp;
// 	}
// 	cout<<"\nSorted array is :";
// 	for(i=0;i<n;i++)
// 	{
// 		cout<<" "<<arr[i];
// 	}
// 	return 0;
// }




// template <class S>      // S is a placeholder

// S add(S a, S b)     // template function
// {
//     return a+b;
// }

// int main()
// {
//     cout<<"Addition is: "<<add(2 , 3)<<endl;
//     cout<<"Addition is: "<<add(12.45 , 3.12)<<endl;
    
//     return 0;
// }





#include <iostream>
using namespace std;
template<class S>
class compare
{
    public:
    
    S big(S a, S b)
    {
        if(a>b)
        return a;
        return b;
    }
};

int main()
{
    compare <int> c;
    cout<<c.big(5,6)<<endl;
    compare <double> c1;
    cout<<c1.big(56.3,3.5)<<endl;
    compare <char> c2;
    cout<<c2.big('a','z');
    
    return 0;
}



