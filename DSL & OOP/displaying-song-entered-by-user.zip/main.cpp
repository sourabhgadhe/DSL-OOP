# include <iostream>
using namespace std;

int main()
{   
    char song[50];
    cout<<"Enter First Line Of ur Favourite Song: "<<endl;
    cin.get(song,50);
    
    cout<<"Entered song is: "<<song;
    return 0;
}
