# include <bits/stdc++.h>
using namespace std;

class Student
{
    public:
    int x;
    
    Student()  //default constructor
    {
        cout<<">> WELCOME TO STUDENT DATABASE SYSTEM <<"<<endl;
    }
    
    ~Student()  //destructor
    {
        cout<<"\n>> THANKS FOR USING STUDENT DATABASE SYSTEM <<"<<endl;
    }
    
    void menu()
    {
        cout<<"\n***  MENU  ***"<<endl;
        cout<<"\n1.Show Existing Database"<<endl;
        cout<<"2.Create/Replace New Database"<<endl;
        cout<<"3.Exit Database"<<endl;
        cout<<"\nChoose one of the above options: ";
        cin>>x;
        cin.ignore();
    }
    
    void showdatabase1()
    {
        cout<<"\nDATABASE: 1"<<endl;
        cout<<"\nName: Sourabh Gadhe"<<endl;
        cout<<"Roll No.: 1817"<<endl;
        cout<<"Class: Computer"<<endl;
        cout<<"Division: A"<<endl;
        cout<<"Date of Birth: 14/04/2002"<<endl;
        cout<<"Blood Group: O+"<<endl;
        cout<<"Address: Loni-Kalbhor, Pune-412201"<<endl;
        cout<<"Contact No.: 9922969980"<<endl;
    }
    
    void showdatabase2()
    {
        cout<<"\nDATABASE: 2"<<endl;
        cout<<"\nName: Nilesh Aware"<<endl;
        cout<<"Roll No.: 1884"<<endl;
        cout<<"Class: IT"<<endl;
        cout<<"Division: B"<<endl;
        cout<<"Date of Birth: 24/07/2001"<<endl;
        cout<<"Blood Group: B-"<<endl;
        cout<<"Address: Shewalwadi, Pune-412201"<<endl;
        cout<<"Contact No.: 8767558734"<<endl;
    }
    
    friend class abc ; //friend class declared
};

class abc
{   
    public:
    int roll_no , dtb;
    string name, cls, division, dob, bldgrp, address, contact;
   
    void createdatabase()
    {   
        cout<<"\nPlease do not enter Existing DATABASE No. !!"<<endl;
        cout<<"First check existing number of DATABASES !! (2 DATABASES already exists !!)"<<endl;
        cout<<"\nEnter DATABASE No.: ";
        cin>>dtb;
        cin.ignore();
        
        cout<<"\nEnter Student's Name: ";
        getline(cin,name);
        
        
        cout<<"Enter Student's Roll_no.: ";
        cin>>roll_no;
        cin.ignore();      // helps to execute next getline function by ignoring newline as input for nxt getline
                          // doesn't skips the next input function
        
        cout<<"Enter Student's Class: ";
        getline(cin,cls);
        
        
        cout<<"Enter Student's Division: ";
        cin>>division;
        cin.ignore();
        
        
        cout<<"Enter Student's Date of Birth: ";
        getline(cin,dob);
        
        
        cout<<"Enter Student's Blood Group: ";
        getline(cin,bldgrp);
        
        
        cout<<"Enter Student's Address: ";
        getline(cin,address);
        
        cout<<"Enter Student's Contact No.: ";
        getline(cin,contact);
        
    
    }
    
    void showdatabase3()
    {
        cout<<"\nDATABASE: "<<dtb<<endl;
        cout<<"\nName: "<<name<<endl;
        cout<<"Roll No.: "<<roll_no<<endl;
        cout<<"Class: "<<cls<<endl;
        cout<<"Division: "<<division<<endl;
        cout<<"Date of Birth: "<<dob<<endl;
        cout<<"Blood Group: "<<bldgrp<<endl;
        cout<<"Address: "<<address<<endl;
        cout<<"Contact No.: "<<contact<<endl;
        
    }

    
};


int main()
{   
    Student s1;
    abc a1;

    while(int i=1)
    {   
        s1.menu();
        if (s1.x==1)
        {
            s1.showdatabase1();
            s1.showdatabase2();
        }
    
        else if (s1.x==2)
        {
            a1.createdatabase();
            s1.showdatabase1();
            s1.showdatabase2();
            a1.showdatabase3();
            cout<<"\n>> DATABASE ADDED SUCCESSFULLY <<"<<endl;

        }
        
        else if(s1.x==3)
        {
            break;
        }
    }

    return 0;
}








