# include <iostream>
# include <fstream>
using namespace std;

class Student
{
    int roll;
    char name[50];
    float marks;

    public:
    
    void getdata()
    {
        cout<<"\nEnter name of the student: ";
        cin>>ws;                                  // cin>>ws is already defined in iostream that ignores buffer and discards all whitespaces
        cin.getline(name,50);
        
        cout<<"Enter roll no. of the student: ";
        cin>>roll;
        
        cout<<"Enter marks of the student: ";  
        cin>>marks; 
        cout<<endl; 

    }
    
    void display ()
    {
        cout<<"\nName: "<<name<<endl; 
        cout<<"Roll No: "<<roll<<endl; 
        cout<<"Marks: "<<marks<<endl; 
    }

};


int main()
{
    int n;
    cout<<"Enter the total no. of students: ";
    cin>>n;
    
    Student s[n];   // array object of student class
    fstream file;  // object of fstream class
    
    file.open("file.txt",ios::out); // Opening file.txt in write mode
    
    if(!file)
    {
        cout<<"\nFile not created !!"<<endl;
    }
    else
    {
        cout<<"\nFile created successfully !!"<<endl;
    }
    
    for(int i=0;i<n;i++)
    {
        s[i].getdata(); 
        file.write((char*)&s[i],sizeof(s[i]));         // type casting &obj (&s[i]) into a character pointer.
    }
    
    file.close(); // closing the file
    cout<<"File saved and closed !!"<<endl;
    
    cout<<endl<<"***** Displaying Data *****"<<endl;
    
    file.open("file.txt",ios::in); // Opening file.txt in read mode

    for (int i = 0; i< n; i++)
    {
        file.read((char*)&s[i],sizeof(s[i]));
        s[i].display();
    }

    file.close(); // closing the file

    return 0;
}

