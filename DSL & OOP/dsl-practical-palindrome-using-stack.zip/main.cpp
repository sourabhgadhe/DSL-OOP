#include <iostream>
#include<stdio.h>
#include <stdlib.h>
#include <string.h>
using namespace std;


class stack
{
    char s[50];
    int top;

public:
    stack()
        {
            top=-1;
        }
    void push(char val);
    char pop();
    int isfull();
    int isempty();

};

class str
{
    char inputstr[50], revstr[50];
    stack stobj;

public:
    void readstring();
    void revstring();
    void convertstring();
    void checkpalindrome();

};

int stack::isempty()
{
    if(top==-1)//stack is empty
        return 1;   
    else
        return 0;   
}

int stack::isfull()
{
    if(top==49)
        return 1;
    else
        return 0;
}

void stack::push(char val)
{
    if(!isfull())
    {
        top++;//top=-1
        s[top]=val;
    }
    else
        cout<<endl<<"Stack is full......"<<endl;
}

char stack::pop()
{
    char val='\0';
    if(!isempty())
    {
        val=s[top];
        top--;

    }
    else
        cout<<endl<<"Stack is empty......"<<endl;
    return val;
}

void str::readstring()
{
    cout<<"\nEnter string  ";
    gets(inputstr);
    cout<<"\nYou entered:-> "<<inputstr;
}

void str::revstring() 
{
    int i;
    char ch;
    for(i=0;inputstr[i]!='\0';i++)
    {
        stobj.push(inputstr[i]);
	}
 i=0;
    cout<<"\n\nAfter reversing your string:-> ";
    while(!stobj.isempty())
    {
        ch=stobj.pop();
        cout<<ch;
        revstr[i]=ch;
        i++;
    }
    cout<<endl;
}

void str::convertstring()
{
    int i,j=0;
    char tempstr[50];
    for(i=0;inputstr[i]!='\0';i++)
    {
        if(inputstr[i]>=97  && inputstr[i]<=122)
        {
            tempstr[j]=inputstr[i];
            j++;
        }
        else if(inputstr[i]>=65 && inputstr[i]<=90)
        {
            tempstr[j]=inputstr[i]+32;
            j++;
        }

    }
    tempstr[j]='\0';
    strcpy(inputstr,tempstr);
    cout<<"\n\nYour converted string:-> "<<inputstr<<endl;
}


void str::checkpalindrome()
{
    cout<<"\n\n";
    cout<<"\nCheck for palindrome"<<endl;

    readstring();
    convertstring();
    for(int i=0;i<49;i++)
    revstr[i]=0;
    revstring();
	
	
    if(strcmp(inputstr,revstr)==0)
        cout<<"\n\nYour string is a PALINDROME";
    else
        cout<<"\n\nYour string is not a PALINDROME";

}

int main()
{
    str obj;
    obj.readstring();
    obj.convertstring();
    obj.revstring();
    obj.checkpalindrome();
    return 0;
}


