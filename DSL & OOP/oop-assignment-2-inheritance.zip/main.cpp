// Imagine a publishing company that markets both book and audiocassette versions of its
// works. Create a class publication that stores the title (a string) and price (type float)
// of a publication. From this class derive two classes: book, which adds a page count (type
// int), and tape, which adds a playing time in minutes (type float).
// Write a program that initiates the book and tape class, allows user to enter data and displays the data members.
// If an exception is caught, replace all the data member values with zero values.


# include <iostream>
using namespace std;

class publication
{
    public:
    string title;
    float price;
    
    void getdata()
 {
     try{
         cout << "\nEnter title of publication: ";
         getline(cin,title);
         
         
         cout << "\nEnter price of publication: ";
         cin >> price;
         
         if (price==0){
             throw price;
         }
         
     }
     
     catch(float b)
     {
         cout<<"\nError !! The price of the publication cannot be 0"<<endl;
         price=0;
         title="None";
         cout<<"\nTitle of publication: "<<title<<endl;
         cout<<"\nThe price of publication: "<<price<<endl;
         exit(0);
     }

 }
 void putdata()
 {
  cout << "\nPublication title: " << title;
  cout << "\nPublication price: " << price;
 }
    
    
};

class book : public publication
{
  public:
  int pagecount;

 void getdata(void)
 {
  cout<< "\n*** Enter Book Details ***\n";
  publication::getdata(); 
  cout << "\nEnter Book Page Count: "; 
  cin >> pagecount;
 }
 void putdata()
 {cout<< "\n*** Book Details ***\n";
  publication::putdata();  
  cout << "\nBook page count: " << pagecount<<endl;
  
 }
 
};


class tape : public publication
{
    public:
    float ptime;
    void getdata()
 {
  cout<< "\n*** Enter Tape Details ***\n";  
  publication::getdata();
  cout << "\nEnter tape's playing time (in minutes): ";
  cin >> ptime;
 }
 void putdata()
 {
  cout<< "\n*** Tape Details ***\n";
  publication::putdata();
  cout << "\nTape's playing time: " << ptime<<" minutes";
 }
    
};

int main()
{
    book b;
    tape t;
    b.getdata();
    cin.ignore();   // ignores space as input & runs getline method
    t.getdata();
    b.putdata();
    t.putdata();
    
    return 0;
}


